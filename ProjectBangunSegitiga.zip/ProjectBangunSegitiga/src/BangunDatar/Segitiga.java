/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BangunDatar;

import Superclass.BangunDatar;
import Interfaces.BangunDatarInterface;

/**
 *
 * @author Asus
 */

//inheritance
//subclass mewarisi attribute dan method superclass. supaya code tidak perlu ditulis ulang. 
//Karena: semua bangun punya nama, semua bangun bisa tampilInfo(), jadi cukup diwariskan.
public class Segitiga extends BangunDatar implements BangunDatarInterface{
    //================
    //encapsulation 
    //================
    //data ukuran segitiga disembunyikan,
    //class lain tidak boleh mengakses langsung.
    // encapsulation bertujuan menyembunyikan informasi dan menjaga data agar tidak diakses langsung oleh class lain.
    private double alas;
    private double tinggi;
    private double sisiA;
    private double sisiB;
    private double sisiC;

    private double luas;
    private double keliling;

    // =========================
    // OVERLOADING
    // Constructor 1
    // =========================

    public Segitiga() {

    }

    // =========================
    // OVERLOADING
    // Constructor 2
    // =========================

    public Segitiga(double alas, double tinggi) {
        this.alas = alas;
        this.tinggi = tinggi;
    }

    // =========================
    // OVERLOADING
    // Constructor 3
    // =========================

    public Segitiga(double alas,
                     double tinggi,
                     double sisiA,
                     double sisiB,
                     double sisiC) {

        this.alas = alas;
        this.tinggi = tinggi;

        this.sisiA = sisiA;
        this.sisiB = sisiB;
        this.sisiC = sisiC;
    }

    // =========================
    // IMPLEMENTASI INTERFACE
    // =========================

    @Override
    public double hitungLuas() {

        luas = 0.5 * alas * tinggi;

        return luas;
    }

    @Override
    public double hitungKeliling() {

        keliling = sisiA + sisiB + sisiC;

        return keliling;
    }

    // =========================
    // OVERRIDING
    // =========================

    @Override
    public void tampilInfo() {

        System.out.println("=== DATA SEGITIGA ===");

        System.out.println("Alas       : " + alas);
        System.out.println("Tinggi     : " + tinggi);

        System.out.println("Luas       : "
                + hitungLuas());

        System.out.println("Keliling   : "
                + hitungKeliling());
    }

    // =========================
    // GETTER & SETTER
    // ENCAPSULATION
    // =========================

    public double getAlas() {
        return alas;
    }

    public void setAlas(double alas) {
        this.alas = alas;
    }

    public double getTinggi() {
        return tinggi;
    }

    public void setTinggi(double tinggi) {
        this.tinggi = tinggi;
    }
}