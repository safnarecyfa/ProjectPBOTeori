/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Main;

/**
 *
 * @author Asus
 */
import BangunDatar.Segitiga;
import BangunRuang.*;
import Multithreading.*;
import GUI.*;

public class ProjectBangunSegitiga {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        // TODO code application logic here
//        //         // =========================
//        //        // POLYMORPHISM
//        //        // =========================
//        //
//        //        BangunRuang br;
//        //
//        //        br = new PrismaSegitiga();
//        //        br.tampilInfo();
//        //
//        //        br = new LimasSegitiga();
//        //        br.tampilInfo();
//        //    }
//    
//        
//        // “Object dipisahkan berdasarkan jenis bangun agar masing-masing thread memiliki tanggung jawab proses yang spesifik.”
//        // =========================
//        // DATA OBJECT
//        // =========================
//        Segitiga[] dataSegitiga
//                = new Segitiga[10000];
//
//        PrismaSegitiga[] dataPrisma
//                = new PrismaSegitiga[10000];
//
//        LimasSegitiga[] dataLimas
//                = new LimasSegitiga[10000];
//
//        // =========================
//        // GENERATE OBJECT
//        // =========================
//        for (int i = 0;
//                i < dataSegitiga.length;
//                i++) {
//
//            Segitiga s
//                    = new Segitiga(
//                            i + 1,
//                            i + 2,
//                            i + 3,
//                            i + 4,
//                            i + 5
//                    );
//
//            dataSegitiga[i] = s;
//
//            dataPrisma[i]
//                    = new PrismaSegitiga(
//                            i + 10,
//                            s
//                    );
//
//            dataLimas[i]
//                    = new LimasSegitiga(
//                            i + 5,
//                            s
//                    );
//        }
//
//        // =========================
//        // OBJECT THREAD
//        // =========================
//        ThreadSegitiga ts
//                = new ThreadSegitiga(
//                        dataSegitiga);
//
//        ThreadPrisma tp
//                = new ThreadPrisma(
//                        dataPrisma);
//
//        ThreadLimas tl
//                = new ThreadLimas(
//                        dataLimas);
//
//        // =========================
//        // THREAD JAVA
//        // =========================
//        Thread thread1
//                = new Thread(ts);
//
//        Thread thread2
//                = new Thread(tp);
//
//        Thread thread3
//                = new Thread(tl);
//
//        // =========================
//        // MENJALANKAN THREAD
//        // =========================
//        thread1.start();
//        thread2.start();
//        thread3.start();
//    }
        new MainFrame();
    }
}
