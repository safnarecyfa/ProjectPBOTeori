/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Multithreading;

import BangunRuang.PrismaSegitiga;

/**
 *
 * @author Asus
 */
public class ThreadPrisma extends Thread implements Runnable {

    private PrismaSegitiga[] dataPrisma;

    public ThreadPrisma(
            PrismaSegitiga[] dataPrisma) {

        this.dataPrisma
                = dataPrisma;
    }

    @Override
    public void run() {

        System.out.println(
                "Thread Prisma Berjalan");

        for (int i = 0;
                i < dataPrisma.length;
                i++) {

            dataPrisma[i]
                    .hitungVolume();

            dataPrisma[i]
                    .hitungLuasPermukaan();
        }

        System.out.println(
                "Thread Prisma Selesai");
    }
}
