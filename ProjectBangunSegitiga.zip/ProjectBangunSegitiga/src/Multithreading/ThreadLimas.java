/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Multithreading;

import BangunRuang.LimasSegitiga;

/**
 *
 * @author Asus
 */
public class ThreadLimas extends Thread implements Runnable {
     private LimasSegitiga[] dataLimas;

    public ThreadLimas(
            LimasSegitiga[] dataLimas) {

        this.dataLimas =
                dataLimas;
    }

    @Override
    public void run() {

        System.out.println(
                "Thread Limas Berjalan");

        for (int i = 0;
             i < dataLimas.length;
             i++) {

            dataLimas[i]
                    .hitungVolume();

            dataLimas[i]
                    .hitungLuasPermukaan();
        }

        System.out.println(
                "Thread Limas Selesai");
    }
}