/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Multithreading;

/**
 *
 * @author Asus
 */
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

import Bangun.Bangun;

import BangunDatar.Segitiga;

import BangunRuang.PrismaSegitiga;
import BangunRuang.LimasSegitiga;

public class Multithreading implements Runnable {

    private Bangun bangun;

    private JTextArea areaLog;
    private DefaultTableModel modelTabel;

    double luas = 0;

    double keliling = 0;

    double volume = 0;

    double luasPermukaan = 0;

    public Multithreading(
            Bangun bangun,
            JTextArea areaLog,
            DefaultTableModel modelTabel) {

        this.bangun = bangun;

        this.areaLog = areaLog;
        this.modelTabel = modelTabel;
    }

    @Override
    public void run() {

        synchronized (areaLog) {

            areaLog.append(
                    "\n----------------------------------------\n");

            areaLog.append(
                    "MEMPROSES : "
                    + bangun.getClass()
                            .getSimpleName()
                    + "\n");

            areaLog.append(
                    "THREAD : "
                    + Thread.currentThread()
                            .getName()
                    + "\n");

            areaLog.append(
                    "----------------------------------------\n");

            // =========================
            // SEGITIGA
            // =========================
            if (bangun instanceof Segitiga) {

                Segitiga s
                        = (Segitiga) bangun;

                luas
                        = s.hitungLuas();

                keliling
                        = s.hitungKeliling();

                areaLog.append(
                        "Luas : "
                        + s.hitungLuas()
                        + "\n");

                areaLog.append(
                        "Keliling : "
                        + s.hitungKeliling()
                        + "\n");
            } // =========================
            // PRISMA
            // =========================
            else if (bangun instanceof PrismaSegitiga) {

                PrismaSegitiga p
                        = (PrismaSegitiga) bangun;
                luas
                        = p.getAlasSegitiga()
                                .hitungLuas();

                keliling
                        = p.getAlasSegitiga()
                                .hitungKeliling();

                volume
                        = p.hitungVolume();

                luasPermukaan
                        = p.hitungLuasPermukaan();

                areaLog.append(
                        "Volume : "
                        + p.hitungVolume()
                        + "\n");

                areaLog.append(
                        "Luas Permukaan : "
                        + p.hitungLuasPermukaan()
                        + "\n");
            } // =========================
            // LIMAS
            // =========================
            else if (bangun instanceof LimasSegitiga) {

                LimasSegitiga l
                        = (LimasSegitiga) bangun;

                luas
                        = l.getAlasSegitiga()
                                .hitungLuas();

                keliling
                        = l.getAlasSegitiga()
                                .hitungKeliling();

                volume
                        = l.hitungVolume();

                luasPermukaan
                        = l.hitungLuasPermukaan();

                areaLog.append(
                        "Volume : "
                        + l.hitungVolume()
                        + "\n");

                areaLog.append(
                        "Luas Permukaan : "
                        + l.hitungLuasPermukaan()
                        + "\n");
            }

            areaLog.append(
                    "----------------------------------\n\n");
        }

        modelTabel.addRow(
                new Object[]{
                    modelTabel.getRowCount() + 1,
                    bangun.getClass()
                            .getSimpleName(),
                    luas,
                    keliling,
                    volume,
                    luasPermukaan
                });
    }
}
