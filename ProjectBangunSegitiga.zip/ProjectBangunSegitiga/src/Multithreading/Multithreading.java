/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Multithreading;

/**
 *
 * @author Asus
 */
import BangunDatar.Segitiga;
import BangunRuang.PrismaSegitiga;
import BangunRuang.LimasSegitiga;

import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

public class Multithreading implements Runnable {

    // DATA
    private Segitiga[] dataSegitiga;
    private PrismaSegitiga[] dataPrisma;
    private LimasSegitiga[] dataLimas;

    // RANGE THREAD
    private int startIndex;
    private int endIndex;

    // GUI
    private JTextArea areaLog;
    private DefaultTableModel modelTabel;

    // CONSTRUCTOR
    public Multithreading(
            Segitiga[] dataSegitiga,
            PrismaSegitiga[] dataPrisma,
            LimasSegitiga[] dataLimas,
            int startIndex,
            int endIndex,
            JTextArea areaLog,
            DefaultTableModel modelTabel) {

        this.dataSegitiga = dataSegitiga;
        this.dataPrisma = dataPrisma;
        this.dataLimas = dataLimas;
        this.startIndex = startIndex;
        this.endIndex = endIndex;
        this.areaLog = areaLog;
        this.modelTabel = modelTabel;
    }

    // THREAD PROCESS
    @Override
    public void run() {

        // HEADER THREAD
        String headerLog
                = "\n====================================\n"
                + "THREAD : "
                + Thread.currentThread()
                        .getName()
                + "\n"
                + "MEMPROSES DATA : "
                + startIndex
                + " sampai "
                + (endIndex - 1)
                + "\n"
                + "====================================\n";

        synchronized (areaLog) {
            areaLog.append(headerLog);
        }

        // PROCESS DATA
        for (int i = startIndex; i < endIndex; i++) {

            // PERHITUNGAN
            double luas = dataSegitiga[i].hitungLuas();
            double keliling = dataSegitiga[i].hitungKeliling();

            double volumePrisma = dataPrisma[i].hitungVolume();
            double luasPrisma = dataPrisma[i].hitungLuasPermukaan();

            double volumeLimas = dataLimas[i].hitungVolume();
            double luasLimas = dataLimas[i].hitungLuasPermukaan();

            try {
                if (i < startIndex + 3) {

                    Thread.sleep(50);
                }

            } catch (InterruptedException ex) {

                synchronized (areaLog) {

                    areaLog.append(
                            "\nTHREAD "
                            + Thread.currentThread().getName()
                            + " DIINTERRUPT!\n");
                }

                return;
            }

            // SAMPLE LOG
            if (i < startIndex + 3) {

                String detailLog
                        = "\n------------------------------------\n"
                        + "THREAD : "
                        + Thread.currentThread()
                                .getName()
                        + "\n"
                        + "MEMPROSES DATA KE-"
                        + i
                        + "\n"
                        + "------------------------------------\n"
                        + "Luas : "
                        + luas
                        + "\n"
                        + "Keliling : "
                        + keliling
                        + "\n"
                        + "Volume Prisma : "
                        + volumePrisma
                        + "\n"
                        + "Volume Limas : "
                        + volumeLimas
                        + "\n";

                synchronized (areaLog) {
                    areaLog.append(detailLog);
                }
            }

            // UPDATE TABLE
            final int row = i;

            String namaBentuk;
            Object volumeTampil;
            Object luasPermukaanTampil;

            if (row % 3 == 0) {
                namaBentuk = "Segitiga";
                volumeTampil = "-";
                luasPermukaanTampil = "-";
            } else if (row % 3 == 1) {
                namaBentuk = "Prisma Segitiga";
                volumeTampil = volumePrisma;
                luasPermukaanTampil = luasPrisma;
            } else {
                namaBentuk = "Limas Segitiga";
                volumeTampil = volumeLimas;
                luasPermukaanTampil = luasLimas;
            }

            SwingUtilities.invokeLater(() -> {

                modelTabel.setValueAt(
                        row + 1,
                        row,
                        0);

                modelTabel.setValueAt(
                        namaBentuk,
                        row,
                        1);

                modelTabel.setValueAt(
                        luas,
                        row,
                        2);

                modelTabel.setValueAt(
                        keliling,
                        row,
                        3);

                modelTabel.setValueAt(
                        volumeTampil,
                        row,
                        4);

                modelTabel.setValueAt(
                        luasPermukaanTampil,
                        row,
                        5);
            });
        }

        // THREAD SELESAI
        synchronized (areaLog) {

            areaLog.append(
                    "\nTHREAD "
                    + Thread.currentThread()
                            .getName()
                    + " SELESAI\n");
        }
    }
}
