/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Multithreading;

import BangunDatar.Segitiga;

/**
 *
 * @author Asus
 */
//Thread adalah unit eksekusi sekumpulan instruksi dalam sebuah class.
//Multithreading memungkinkan beberapa thread berjalan secara konkuren/simultan.
//Thread BUKAN membuat object. Object sudah dibuat di STEP sebelumnya.
//Thread tugasnya: memproses object-object tersebut.
public class ThreadSegitiga extends Thread implements Runnable {
    // =========================
    // ATTRIBUTE
    // =========================

    private Segitiga[] dataSegitiga;

    // =========================
    // CONSTRUCTOR
    // =========================
    public ThreadSegitiga(
            Segitiga[] dataSegitiga) {

        this.dataSegitiga
                = dataSegitiga;
    }

    // =========================
    // METHOD RUN
    // THREAD PROCESS
    // =========================
    @Override
    public void run() {

        System.out.println(
                "Thread Segitiga Berjalan");

        for (int i = 0;
                i < dataSegitiga.length;
                i++) {

            dataSegitiga[i]
                    .hitungLuas();

            dataSegitiga[i]
                    .hitungKeliling();
        }

        System.out.println(
                "Thread Segitiga Selesai");
    }
}
