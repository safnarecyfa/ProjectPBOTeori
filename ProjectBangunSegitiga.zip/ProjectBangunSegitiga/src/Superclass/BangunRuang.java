/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Superclass;

import Bangun.Bangun;

/**
 *
 * @author Asus
 */
public class BangunRuang extends Bangun {
    
    protected String namaBangun;
    protected String warna;

    protected double volume;
    protected double luasPermukaan;

    public void tampilInfo() {
        System.out.println("Nama Bangun : " + namaBangun);
    }
}
