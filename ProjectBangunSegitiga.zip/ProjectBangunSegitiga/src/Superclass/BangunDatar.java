/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Superclass;

import Bangun.Bangun;

/**
 *
 * @author Asus
 */
public class BangunDatar extends Bangun {

    // INHERITANCE
    // Attribute ini diwariskan ke subclass

    protected String namaBangun;
    protected String warna;

    public BangunDatar() {
        namaBangun = "Bangun Datar";
        warna = "Putih";
    }

    public void tampilInfo() {
        System.out.println("Nama Bangun : " + namaBangun);
        System.out.println("Warna       : " + warna);
    }
}