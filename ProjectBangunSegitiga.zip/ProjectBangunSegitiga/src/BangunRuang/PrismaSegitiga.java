/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BangunRuang;

import BangunDatar.Segitiga;
import Superclass.BangunRuang;
import Interfaces.BangunRuangInterface;


/**
 *
 * @author Asus
 */
public class PrismaSegitiga extends BangunRuang implements BangunRuangInterface{
    // ENCAPSULATION

    private double tinggiPrisma;

    // ANATOMY / HAS-A RELATIONSHIP

    private Segitiga alasSegitiga;

    public PrismaSegitiga() {

    }

    // OVERLOADING

    public PrismaSegitiga(
            double tinggiPrisma,
            Segitiga alasSegitiga) {

        this.tinggiPrisma = tinggiPrisma;
        this.alasSegitiga = alasSegitiga;
    }

    @Override
    public double hitungVolume() {

        volume =
                alasSegitiga.hitungLuas()
                * tinggiPrisma;

        return volume;
    }

    @Override
    public double hitungLuasPermukaan() {

        luasPermukaan =
                2 * alasSegitiga.hitungLuas();

        return luasPermukaan;
    }

    // OVERRIDING

    @Override
    public void tampilInfo() {

        System.out.println(
                "=== PRISMA SEGITIGA ===");

        System.out.println(
                "Volume : "
                        + hitungVolume());
    }
}
