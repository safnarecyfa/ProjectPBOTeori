/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BangunRuang;

import BangunDatar.Segitiga;

/**
 *
 * @author Asus
 */
public class PrismaSegitiga extends Segitiga implements BangunRuangInterface {
    // ENCAPSULATION
    private double tinggiPrisma;

    private double volume;
    private double luasPermukaan;

    public PrismaSegitiga() {

    }

    public PrismaSegitiga(
            double alas,
            double tinggi,
            double sisiA,
            double sisiB,
            double sisiC,
            double tinggiPrisma) {

        super(alas, tinggi, sisiA, sisiB, sisiC);
        this.tinggiPrisma = tinggiPrisma;
    }

    @Override
    public double hitungVolume() {
        volume = hitungLuas() * tinggiPrisma;
        return volume;
    }

    @Override
    public double hitungLuasPermukaan() {
        luasPermukaan = 2 * hitungLuas();
        return luasPermukaan;
    }
}