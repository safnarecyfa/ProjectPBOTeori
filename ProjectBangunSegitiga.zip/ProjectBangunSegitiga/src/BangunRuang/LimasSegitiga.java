/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BangunRuang;

import BangunDatar.Segitiga;

/**
 *
 * @author Asus
 */
public class LimasSegitiga extends Segitiga implements BangunRuangInterface {

    // ENCAPSULATION
    private double tinggiLimas;

    private double volume;
    private double luasPermukaan;

    public LimasSegitiga() {

    }

    public LimasSegitiga(
            double alas,
            double tinggi,
            double sisiA,
            double sisiB,
            double sisiC,
            double tinggiLimas) {
        
        super(alas, tinggi, sisiA, sisiB, sisiC);
        this.tinggiLimas = tinggiLimas;
    }

    @Override
    public double hitungVolume() {
        volume = (1.0/3.0) * hitungLuas() * tinggiLimas;
        return volume;
    }

    @Override
    public double hitungLuasPermukaan() {
        luasPermukaan = 2 * hitungLuas() * tinggiLimas;
        return luasPermukaan;
    }
}
