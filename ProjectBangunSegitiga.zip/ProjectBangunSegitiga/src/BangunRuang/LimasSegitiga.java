/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BangunRuang;

import BangunDatar.Segitiga;
import Superclass.BangunRuang;
import Interfaces.BangunRuangInterface;

/**
 *
 * @author Asus
 */
public class LimasSegitiga extends BangunRuang implements BangunRuangInterface {
        // =========================
    // ENCAPSULATION
    // =========================

    private double tinggiLimas;

    // =========================
    // ANATOMY / HAS-A
    // =========================

    private Segitiga alasSegitiga;

    // =========================
    // OVERLOADING
    // Constructor kosong
    // =========================

    public LimasSegitiga() {

    }

    // =========================
    // OVERLOADING
    // Constructor berparameter
    // =========================

    public LimasSegitiga(
            double tinggiLimas,
            Segitiga alasSegitiga) {

        this.tinggiLimas = tinggiLimas;
        this.alasSegitiga = alasSegitiga;
    }

    // =========================
    // IMPLEMENTASI INTERFACE
    // =========================

    @Override
    public double hitungVolume() {

        volume =
                (1.0 / 3.0)
                * alasSegitiga.hitungLuas()
                * tinggiLimas;

        return volume;
    }

    @Override
    public double hitungLuasPermukaan() {

        // Versi sederhana dulu
        luasPermukaan =
                alasSegitiga.hitungLuas()
                + (3 * alasSegitiga.hitungLuas());

        return luasPermukaan;
    }

    // =========================
    // OVERRIDING
    // =========================

    @Override
    public void tampilInfo() {

        System.out.println(
                "=== LIMAS SEGITIGA ===");

        System.out.println(
                "Tinggi Limas : "
                        + tinggiLimas);

        System.out.println(
                "Volume : "
                        + hitungVolume());

        System.out.println(
                "Luas Permukaan : "
                        + hitungLuasPermukaan());
    }

    // =========================
    // GETTER & SETTER
    // ENCAPSULATION
    // =========================

    public double getTinggiLimas() {
        return tinggiLimas;
    }

    public void setTinggiLimas(
            double tinggiLimas) {

        this.tinggiLimas = tinggiLimas;
    }

    public Segitiga getAlasSegitiga() {
        return alasSegitiga;
    }

    public void setAlasSegitiga(
            Segitiga alasSegitiga) {

        this.alasSegitiga = alasSegitiga;
    }
   
}
