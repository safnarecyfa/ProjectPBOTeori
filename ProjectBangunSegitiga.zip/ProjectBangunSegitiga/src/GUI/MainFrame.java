/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

/**
 *
 * @author Asus
 */
import BangunDatar.Segitiga;
import BangunRuang.PrismaSegitiga;
import BangunRuang.LimasSegitiga;
import Exception.InputTidakValidException;

import Multithreading.Multithreading;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.*;

public class MainFrame
        extends JFrame
        implements ActionListener {

    // =========================
    // LABEL
    // =========================
    private JLabel lJumlahData;

    private JLabel lJumlahThread;

    // =========================
    // TEXT FIELD
    // =========================
    private JTextField tfJumlahData;

    private JTextField tfJumlahThread;

    // =========================
    // BUTTON
    // =========================
    private JButton btnGenerate;

    private JButton btnStartThread;

    // =========================
    // LOG
    // =========================
    private JTextArea areaLog;

    private JScrollPane scrollLog;

    // =========================
    // TABLE
    // =========================
    private JTable tabelRingkasan;

    private DefaultTableModel modelTabel;

    private JScrollPane scrollTabel;

    // =========================
    // DATA OBJECT
    // =========================
    private Segitiga[] dataSegitiga;

    private PrismaSegitiga[] dataPrisma;

    private LimasSegitiga[] dataLimas;

    private JButton btnReset;

    // =========================
    // CONSTRUCTOR
    // =========================
    public MainFrame() {

        super("Geometri - Multithreading");

        // =========================
        // LABEL
        // =========================
        lJumlahData
                = new JLabel("Jumlah Data");

        lJumlahThread
                = new JLabel("Jumlah Thread");

        // =========================
        // TEXT FIELD
        // =========================
        tfJumlahData
                = new JTextField("10000", 10);

        tfJumlahThread
                = new JTextField("10", 10);

        // =========================
        // BUTTON
        // =========================
        btnGenerate
                = new JButton("Generate Data");

        btnStartThread
                = new JButton("Start Multithreading");

        // =========================
        // LOG
        // =========================
        areaLog
                = new JTextArea();

        scrollLog
                = new JScrollPane(areaLog);

        // =========================
        // TABLE
        // =========================
        String[] namaKolom = {
            "No",
            "Bentuk",
            "Luas",
            "Keliling",
            "Volume",
            "Luas Permukaan"
        };

        modelTabel
                = new DefaultTableModel(
                        namaKolom,
                        0);

        tabelRingkasan
                = new JTable(modelTabel);

        scrollTabel
                = new JScrollPane(tabelRingkasan);

        scrollTabel.setPreferredSize(
                new Dimension(700, 150));

        btnReset
                = new JButton("Reset");

        // =========================
        // CONTAINER
        // =========================
        Container c
                = getContentPane();

        c.setLayout(
                new BorderLayout());

        // =========================
        // PANEL ATAS
        // =========================
        JPanel panelAtas
                = new JPanel();

        panelAtas.add(lJumlahData);

        panelAtas.add(tfJumlahData);

        panelAtas.add(lJumlahThread);

        panelAtas.add(tfJumlahThread);

        panelAtas.add(btnGenerate);

        panelAtas.add(btnStartThread);

        panelAtas.add(btnReset);

        // =========================
        // ADD COMPONENT
        // =========================
        c.add(
                panelAtas,
                BorderLayout.NORTH);

        c.add(
                scrollLog,
                BorderLayout.CENTER);

        c.add(
                scrollTabel,
                BorderLayout.SOUTH);

        // =========================
        // EVENT
        // =========================
        btnGenerate
                .addActionListener(this);

        btnStartThread
                .addActionListener(this);

        btnReset.addActionListener(this);

        // =========================
        // FRAME
        // =========================
        setSize(800, 600);

        setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE);

        setVisible(true);

    }

    // =========================
    // EVENT HANDLER
    // =========================
    @Override
    public void actionPerformed(
            ActionEvent e) {

        if (e.getSource()
                == btnGenerate) {

            generateData();
        }

        if (e.getSource()
                == btnStartThread) {

            startThread();
        }

        if (e.getSource()
                == btnReset) {

            resetData();
        }
    }

    public void resetData() {

        // =========================
        // RESET LOG
        // =========================
        areaLog.setText("");

        // =========================
        // RESET TABLE
        // =========================
        modelTabel.setRowCount(0);

        // =========================
        // RESET ARRAY OBJECT
        // =========================
        dataSegitiga = null;

        dataPrisma = null;

        dataLimas = null;

        // =========================
        // RESET INPUT
        // =========================
        tfJumlahData.setText("10000");

        tfJumlahThread.setText("10");

        // =========================
        // INFO
        // =========================
        JOptionPane.showMessageDialog(
                this,
                "Data berhasil di-reset!");
    }

    // =========================
    // GENERATE DATA
    // =========================
    public void generateData() {

        try {

            areaLog.append(
                    "=== GENERATE DATA ===\n");

            int jumlahData
                    = Integer.parseInt(
                            tfJumlahData.getText());

            // =========================
            // ARRAY OBJECT
            // =========================
            dataSegitiga
                    = new Segitiga[jumlahData];

            dataPrisma
                    = new PrismaSegitiga[jumlahData];

            dataLimas
                    = new LimasSegitiga[jumlahData];

            // =========================
            // GENERATE OBJECT
            // =========================
            for (int i = 0;
                    i < jumlahData;
                    i++) {

                Segitiga s
                        = new Segitiga(
                                i + 1,
                                i + 2,
                                i + 3,
                                i + 4,
                                i + 5
                        );

                dataSegitiga[i] = s;

                dataPrisma[i]
                        = new PrismaSegitiga(
                                i + 10,
                                s);

                dataLimas[i]
                        = new LimasSegitiga(
                                i + 5,
                                s);
            }

            areaLog.append(
                    "[OK] "
                    + (jumlahData * 3)
                    + " object berhasil dibuat\n\n");

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Input jumlah data harus angka!");
        }
    }

    // =========================
    // MULTITHREADING
    // =========================
    public void startThread() {

        try {

            int jumlahData
                    = Integer.parseInt(
                            tfJumlahData.getText());

            int jumlahThread
                    = Integer.parseInt(
                            tfJumlahThread.getText());

            validasiInput(
                    jumlahData,
                    jumlahThread);

            areaLog.append(
                    "=== MULTITHREADING ===\n\n");

            // =========================
            // RESET TABLE
            // =========================
            modelTabel.setRowCount(0);

            // =========================
            // THREAD
            // =========================
            for (int i = 0;
                    i < jumlahThread;
                    i++) {

                Thread t1
                        = new Thread(
                                new Multithreading(
                                        dataSegitiga[i],
                                        areaLog,
                                        modelTabel));

                Thread t2
                        = new Thread(
                                new Multithreading(
                                        dataPrisma[i],
                                        areaLog,
                                        modelTabel));

                Thread t3
                        = new Thread(
                                new Multithreading(
                                        dataLimas[i],
                                        areaLog,
                                        modelTabel));

                t1.start();

                t2.start();

                t3.start();
            }

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Input harus berupa angka!");
        } catch (NullPointerException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Generate data terlebih dahulu!");
        } catch (InputTidakValidException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage());
        }
    }

    public void validasiInput(
            int jumlahData,
            int jumlahThread)
            throws InputTidakValidException {

        if (jumlahData <= 0) {

            throw new InputTidakValidException(
                    "Jumlah data harus lebih dari 0!");
        }

        if (jumlahThread <= 0) {

            throw new InputTidakValidException(
                    "Jumlah thread harus lebih dari 0!");
        }

        if (jumlahThread > jumlahData) {

            throw new InputTidakValidException(
                    "Jumlah thread tidak boleh melebihi jumlah data!");
        }
    }
}
