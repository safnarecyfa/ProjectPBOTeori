/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

/**
 *
 * @author Asus
 */
import BangunDatar.Segitiga;
import BangunRuang.*;

import Multithreading.Multithreading;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.text.DecimalFormat;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

public class MainFrame extends JFrame implements ActionListener {

    // LABEL
    private JLabel lJumlahData;
    private JLabel lJumlahThread;

    // TEXT FIELD
    private JTextField tfJumlahData;
    private JTextField tfJumlahThread;

    // BUTTON
    private JButton btnGenerate;
    private JButton btnStartThread;
    private JButton btnReset;

    // LOG
    private JTextArea areaLog;
    private JScrollPane scrollLog;

    // TABLE
    private JTable tabelRingkasan;
    private DefaultTableModel modelTabel;
    private JScrollPane scrollTabel;

    // DATA OBJECT
    private Segitiga[] dataSegitiga;
    private PrismaSegitiga[] dataPrisma;
    private LimasSegitiga[] dataLimas;

    private long waktuMulai;
    private long waktuSelesai;

    // CONSTRUCTOR
    public MainFrame() {

        super("Geometri - Multithreading");

        // =========================
        // WARNA & FONT
        // =========================
        Color bgColor = new Color(245, 247, 250);
        Color primary = new Color(52, 152, 219);
        Color success = new Color(46, 204, 113);
        Color danger = new Color(231, 76, 60);

        Font fontLabel = new Font("Segoe UI", Font.BOLD, 14);
        Font fontInput = new Font("Segoe UI", Font.PLAIN, 14);
        Font fontButton = new Font("Segoe UI", Font.BOLD, 13);

        // =========================
        // LABEL
        // =========================
        lJumlahData = new JLabel("Jumlah Data");
        lJumlahThread = new JLabel("Jumlah Thread");

        lJumlahData.setFont(fontLabel);
        lJumlahThread.setFont(fontLabel);

        // =========================
        // TEXT FIELD
        // =========================
        tfJumlahData = new JTextField("10000", 10);
        tfJumlahThread = new JTextField("10", 10);

        tfJumlahData.setFont(fontInput);
        tfJumlahThread.setFont(fontInput);

        // =========================
        // BUTTON
        // =========================
        btnGenerate = new JButton("Generate Data");
        btnStartThread = new JButton("Start Multithreading");
        btnReset = new JButton("Reset");

        JButton[] buttons = {
            btnGenerate,
            btnStartThread,
            btnReset
        };

        for (JButton btn : buttons) {

            btn.setFocusPainted(false);
            btn.setFont(fontButton);
            btn.setForeground(Color.WHITE);
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btn.setPreferredSize(new Dimension(180, 40));
        }

        btnGenerate.setBackground(primary);
        btnStartThread.setBackground(success);
        btnReset.setBackground(danger);

        // =========================
        // LOG AREA
        // =========================
        areaLog = new JTextArea();

        areaLog.setFont(new Font("Consolas", Font.PLAIN, 13));
        areaLog.setEditable(false);
        areaLog.setBackground(new Color(44, 62, 80));
        areaLog.setForeground(Color.WHITE);

        scrollLog = new JScrollPane(areaLog);

        scrollLog.setBorder(
                new TitledBorder("Log Multithreading"));

        // =========================
        // TABLE
        // =========================
        String[] namaKolom = {
            "No",
            "Bentuk",
            "Luas",
            "Keliling",
            "Volume",
            "Luas Permukaan"
        };

        modelTabel = new DefaultTableModel(namaKolom, 0);

        tabelRingkasan = new JTable(modelTabel);

        tabelRingkasan.setRowHeight(25);
        tabelRingkasan.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabelRingkasan.getTableHeader().setFont(
                new Font("Segoe UI", Font.BOLD, 13));

        tabelRingkasan.getTableHeader().setBackground(primary);
        tabelRingkasan.getTableHeader().setForeground(Color.WHITE);

        scrollTabel = new JScrollPane(tabelRingkasan);

        scrollTabel.setPreferredSize(
                new Dimension(700, 180));

        scrollTabel.setBorder(
                new TitledBorder("Hasil Perhitungan"));

        // =========================
        // PANEL ATAS
        // =========================
        JPanel panelAtas = new JPanel();

        panelAtas.setBackground(bgColor);

        panelAtas.setBorder(
                new EmptyBorder(15, 15, 15, 15));

        panelAtas.add(lJumlahData);
        panelAtas.add(tfJumlahData);

        panelAtas.add(Box.createHorizontalStrut(15));

        panelAtas.add(lJumlahThread);
        panelAtas.add(tfJumlahThread);

        panelAtas.add(Box.createHorizontalStrut(20));

        panelAtas.add(btnGenerate);
        panelAtas.add(btnStartThread);
        panelAtas.add(btnReset);

        // =========================
        // TITLE
        // =========================
        JLabel title = new JLabel(
                "GEOMETRY MULTITHREADING");

        title.setFont(
                new Font("Segoe UI", Font.BOLD, 24));

        title.setHorizontalAlignment(SwingConstants.CENTER);

        title.setBorder(
                new EmptyBorder(15, 0, 10, 0));

        // =========================
        // MAIN PANEL
        // =========================
        JPanel mainPanel = new JPanel(
                new BorderLayout(10, 10));

        mainPanel.setBackground(bgColor);

        mainPanel.setBorder(
                new EmptyBorder(10, 10, 10, 10));

        mainPanel.add(title, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(
                new BorderLayout(10, 10));

        centerPanel.setBackground(bgColor);

        centerPanel.add(panelAtas, BorderLayout.NORTH);
        centerPanel.add(scrollLog, BorderLayout.CENTER);
        centerPanel.add(scrollTabel, BorderLayout.SOUTH);

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        // =========================
        // ADD COMPONENT
        // =========================
        setContentPane(mainPanel);

        // =========================
        // EVENT
        // =========================
        btnGenerate.addActionListener(this);
        btnStartThread.addActionListener(this);
        btnReset.addActionListener(this);

        // =========================
        // FRAME
        // =========================
        setSize(1000, 700);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setVisible(true);
    }

    // EVENT HANDLER
    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == btnGenerate) {
            generateData();
        }
        if (e.getSource() == btnStartThread) {
            startThread();
        }
        if (e.getSource() == btnReset) {
            resetData();
        }
    }

    public void resetData() {
        // RESET LOG
        areaLog.setText("");

        // RESET TABLE
        modelTabel.setRowCount(0);

        // RESET ARRAY OBJECT
        dataSegitiga = null;
        dataPrisma = null;
        dataLimas = null;

        // RESET INPUT
        tfJumlahData.setText("10000");
        tfJumlahThread.setText("10");

        // INFO
        JOptionPane.showMessageDialog(this, "Data berhasil di-reset!");
    }

    // =========================
    // GENERATE DATA
    // =========================
    public void generateData() {

        try {

            areaLog.append(
                    "=== GENERATE DATA ===\n");

            int jumlahData = Integer.parseInt(tfJumlahData.getText());

            // ARRAY OBJECT
            dataSegitiga = new Segitiga[jumlahData];
            dataPrisma = new PrismaSegitiga[jumlahData];
            dataLimas = new LimasSegitiga[jumlahData];

            // GENERATE OBJECT
            for (int i = 0;
                    i < jumlahData;
                    i++) {

                double alas = i + 3;

                double tinggi = i + 4;

                double sisiMiring
                        = Math.sqrt(
                                (alas * alas)
                                + (tinggi * tinggi));

                Segitiga s
                        = new Segitiga(
                                alas,
                                tinggi,
                                alas,
                                tinggi,
                                sisiMiring
                        ) {
                };

                dataSegitiga[i] = s;

                dataPrisma[i]
                        = new PrismaSegitiga(
                                alas,
                                tinggi,
                                alas,
                                tinggi,
                                sisiMiring,
                                i + 10
                        );

                dataLimas[i]
                        = new LimasSegitiga(
                                alas,
                                tinggi,
                                alas,
                                tinggi,
                                sisiMiring,
                                i + 5
                        );
            }

            areaLog.append(
                    "[OK] "
                    + jumlahData
                    + " data berhasil dibuat");

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Input jumlah data harus angka!");
        }
    }

    // =========================
    // MULTITHREADING
    // =========================
    public void startThread() {

        areaLog.append("=== MULTITHREADING ===\n\n");

        waktuMulai = System.currentTimeMillis();

        modelTabel.setRowCount(0);

        for (int i = 0;
                i < dataSegitiga.length;
                i++) {

            modelTabel.addRow(
                    new Object[6]);
        }

        int jumlahData
                = dataSegitiga.length;

        int jumlahThread
                = Integer.parseInt(
                        tfJumlahThread.getText());

        int dataPerThread
                = jumlahData / jumlahThread;

        // ARRAY THREAD
        Thread[] daftarThread
                = new Thread[jumlahThread];

        // =========================
        // BUAT & START THREAD
        // =========================
        for (int i = 0;
                i < jumlahThread;
                i++) {

            int startIndex
                    = i * dataPerThread;

            int endIndex;

            // THREAD TERAKHIR
            if (i == jumlahThread - 1) {

                endIndex = jumlahData;

            } else {

                endIndex
                        = startIndex
                        + dataPerThread;
            }

            Thread thread
                    = new Thread(
                            new Multithreading(
                                    dataSegitiga,
                                    dataPrisma,
                                    dataLimas,
                                    startIndex,
                                    endIndex,
                                    areaLog,
                                    modelTabel));

            daftarThread[i] = thread;

            System.out.println(
                    "Thread ke-"
                    + i
                    + " berhasil dibuat");

            thread.start();
        }

        // =========================
        // INTERRUPT THREAD KE-2
        // =========================
//        if (jumlahThread > 2) {
//
//            daftarThread[2].interrupt();
//        }

        // =========================
        // JOIN THREAD
        // =========================
        try {

            for (Thread t : daftarThread) {

                if (t != null) {

                    t.join();
                }
            }

        } catch (InterruptedException ex) {

            ex.printStackTrace();
        }

        // =========================
        // WAKTU EKSEKUSI
        // =========================
        waktuSelesai
                = System.currentTimeMillis();

        double durasi
                = (waktuSelesai - waktuMulai)
                / 1000.0;

        DecimalFormat df
                = new DecimalFormat("#.###");

        areaLog.append(
                "\n====================================\n");

        areaLog.append(
                "WAKTU EKSEKUSI : "
                + df.format(durasi)
                + " detik\n");

        areaLog.append(
                "====================================\n");
    }
}
