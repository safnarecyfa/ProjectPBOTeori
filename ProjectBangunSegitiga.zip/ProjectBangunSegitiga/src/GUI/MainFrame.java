/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

/**
 *
 * @author Asus
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainFrame extends JFrame
        implements ActionListener {

    // =========================
    // COMPONENT
    // =========================

    JButton btnSegitiga;
    JButton btnPrisma;
    JButton btnLimas;

    // =========================
    // CONSTRUCTOR
    // =========================

    public MainFrame() {

        super("Triangle Geometry System");

        // =========================
        // COMPONENT
        // =========================

        btnSegitiga =
                new JButton("Form Segitiga");

        btnPrisma =
                new JButton("Form Prisma");

        btnLimas =
                new JButton("Form Limas");

        // =========================
        // CONTAINER
        // =========================

        Container c =
                getContentPane();

        // =========================
        // LAYOUT
        // =========================

        c.setLayout(
                new GridLayout(3,1));

        // =========================
        // ADD COMPONENT
        // =========================

        c.add(btnSegitiga);
        c.add(btnPrisma);
        c.add(btnLimas);

        // =========================
        // EVENT LISTENER
        // =========================

        btnSegitiga.addActionListener(this);
        btnPrisma.addActionListener(this);
        btnLimas.addActionListener(this);

        // =========================
        // FRAME
        // =========================

        setSize(400,300);

        setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE);

        setVisible(true);
    }

    // =========================
    // EVENT HANDLER
    // =========================

    @Override
    public void actionPerformed(
            ActionEvent e) {

        if (e.getSource()
                == btnSegitiga) {

            new FormSegitiga();
        }

        if (e.getSource()
                == btnPrisma) {

            new FormPrisma();
        }

        if (e.getSource()
                == btnLimas) {

            new FormLimas();
        }
    }
}