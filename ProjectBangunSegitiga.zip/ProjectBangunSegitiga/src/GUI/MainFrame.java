/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

/**
 *
 * @author Asus
 */
import BangunDatar.Segitiga;
import BangunRuang.*;
import Exception.InputTidakValidException;

import Multithreading.Multithreading;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.text.DecimalFormat;

public class MainFrame extends JFrame implements ActionListener {

    // LABEL
    private JLabel lJumlahData;
    private JLabel lJumlahThread;

    // TEXT FIELD
    private JTextField tfJumlahData;
    private JTextField tfJumlahThread;

    // BUTTON
    private JButton btnGenerate;
    private JButton btnStartThread;
    private JButton btnReset;

    // LOG
    private JTextArea areaLog;
    private JScrollPane scrollLog;

    // TABLE
    private JTable tabelRingkasan;
    private DefaultTableModel modelTabel;
    private JScrollPane scrollTabel;

    // DATA OBJECT
    private Segitiga[] dataSegitiga;
    private PrismaSegitiga[] dataPrisma;
    private LimasSegitiga[] dataLimas;

    private long waktuMulai;
    private long waktuSelesai;

    // CONSTRUCTOR
    public MainFrame() {
        super("Geometri - Multithreading");

        // LABEL
        lJumlahData = new JLabel("Jumlah Data");
        lJumlahThread = new JLabel("Jumlah Thread");

        // TEXT FIELD
        tfJumlahData = new JTextField("10000", 10);
        tfJumlahThread = new JTextField("10", 10);

        // BUTTON
        btnGenerate = new JButton("Generate Data");
        btnStartThread = new JButton("Start Multithreading");

        // LOG
        areaLog = new JTextArea();
        scrollLog = new JScrollPane(areaLog);

        // TABLE
        String[] namaKolom = {
            "No",
            "Bentuk",
            "Luas",
            "Keliling",
            "Volume",
            "Luas Permukaan"
        };

        modelTabel = new DefaultTableModel(namaKolom, 0);
        tabelRingkasan = new JTable(modelTabel);
        scrollTabel = new JScrollPane(tabelRingkasan);
        scrollTabel.setPreferredSize(new Dimension(700, 150));

        btnReset = new JButton("Reset");

        // CONTAINER
        Container c = getContentPane();

        c.setLayout(new BorderLayout());

        // PANEL ATAS
        JPanel panelAtas = new JPanel();

        panelAtas.add(lJumlahData);
        panelAtas.add(tfJumlahData);
        panelAtas.add(lJumlahThread);
        panelAtas.add(tfJumlahThread);
        panelAtas.add(btnGenerate);
        panelAtas.add(btnStartThread);
        panelAtas.add(btnReset);

        // ADD COMPONENT
        c.add(panelAtas, BorderLayout.NORTH);
        c.add(scrollLog, BorderLayout.CENTER);
        c.add(scrollTabel, BorderLayout.SOUTH);

        // EVENT
        btnGenerate.addActionListener(this);
        btnStartThread.addActionListener(this);
        btnReset.addActionListener(this);

        // FRAME
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    // EVENT HANDLER
    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == btnGenerate) {
            generateData();
        }
        if (e.getSource() == btnStartThread) {
            startThread();
        }
        if (e.getSource() == btnReset) {
            resetData();
        }
    }

    public void resetData() {
        // RESET LOG
        areaLog.setText("");

        // RESET TABLE
        modelTabel.setRowCount(0);

        // RESET ARRAY OBJECT
        dataSegitiga = null;
        dataPrisma = null;
        dataLimas = null;

        // RESET INPUT
        tfJumlahData.setText("10000");
        tfJumlahThread.setText("10");

        // INFO
        JOptionPane.showMessageDialog(this, "Data berhasil di-reset!");
    }

    // =========================
    // GENERATE DATA
    // =========================
    public void generateData() {

        try {

            areaLog.append(
                    "=== GENERATE DATA ===\n");

            int jumlahData = Integer.parseInt(tfJumlahData.getText());

            // ARRAY OBJECT
            dataSegitiga = new Segitiga[jumlahData];
            dataPrisma = new PrismaSegitiga[jumlahData];
            dataLimas = new LimasSegitiga[jumlahData];

            // GENERATE OBJECT
            for (int i = 0;
                    i < jumlahData;
                    i++) {

                double alas = i + 3;

                double tinggi = i + 4;

                double sisiMiring
                        = Math.sqrt(
                                (alas * alas)
                                + (tinggi * tinggi));

                Segitiga s
                        = new Segitiga(
                                alas,
                                tinggi,
                                alas,
                                tinggi,
                                sisiMiring
                        ) {
                };

                dataSegitiga[i] = s;

                dataPrisma[i]
                        = new PrismaSegitiga(
                                alas,
                                tinggi,
                                alas,
                                tinggi,
                                sisiMiring,
                                i + 10
                        );

                dataLimas[i]
                        = new LimasSegitiga(
                                alas,
                                tinggi,
                                alas,
                                tinggi,
                                sisiMiring,
                                i + 5
                        );
            }

            areaLog.append(
                    "[OK] "
                    + jumlahData
                    + " data berhasil dibuat");

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Input jumlah data harus angka!");
        }
    }

    // =========================
    // MULTITHREADING
    // =========================
    public void startThread() {

        areaLog.append("=== MULTITHREADING ===\n\n");

        waktuMulai = System.currentTimeMillis();

        modelTabel.setRowCount(0);

        for (int i = 0;
                i < dataSegitiga.length;
                i++) {

            modelTabel.addRow(
                    new Object[6]);
        }

        int jumlahData
                = dataSegitiga.length;

        int jumlahThread
                = Integer.parseInt(
                        tfJumlahThread.getText());

        int dataPerThread
                = jumlahData / jumlahThread;

        // ARRAY THREAD
        Thread[] daftarThread
                = new Thread[jumlahThread];

        // =========================
        // BUAT & START THREAD
        // =========================
        for (int i = 0;
                i < jumlahThread;
                i++) {

            int startIndex
                    = i * dataPerThread;

            int endIndex;

            // THREAD TERAKHIR
            if (i == jumlahThread - 1) {

                endIndex = jumlahData;

            } else {

                endIndex
                        = startIndex
                        + dataPerThread;
            }

            Thread thread
                    = new Thread(
                            new Multithreading(
                                    dataSegitiga,
                                    dataPrisma,
                                    dataLimas,
                                    startIndex,
                                    endIndex,
                                    areaLog,
                                    modelTabel));

            daftarThread[i] = thread;

            System.out.println(
                    "Thread ke-"
                    + i
                    + " berhasil dibuat");

            thread.start();
        }

        // =========================
        // INTERRUPT THREAD KE-2
        // =========================
        if (jumlahThread > 2) {

            daftarThread[2].interrupt();
        }

        // =========================
        // JOIN THREAD
        // =========================
        try {

            for (Thread t : daftarThread) {

                if (t != null) {

                    t.join();
                }
            }

        } catch (InterruptedException ex) {

            ex.printStackTrace();
        }

        // =========================
        // WAKTU EKSEKUSI
        // =========================
        waktuSelesai
                = System.currentTimeMillis();

        double durasi
                = (waktuSelesai - waktuMulai)
                / 1000.0;

        DecimalFormat df
                = new DecimalFormat("#.###");

        areaLog.append(
                "\n====================================\n");

        areaLog.append(
                "WAKTU EKSEKUSI : "
                + df.format(durasi)
                + " detik\n");

        areaLog.append(
                "====================================\n");
    }
}
