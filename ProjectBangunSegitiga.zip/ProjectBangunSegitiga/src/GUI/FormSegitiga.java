/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

/**
 *
 * @author Asus
 */
import BangunDatar.Segitiga;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FormSegitiga
        extends JFrame
        implements ActionListener {

    JLabel lAlas;
    JLabel lTinggi;
    JLabel lSisiA;
    JLabel lSisiB;
    JLabel lSisiC;

    JTextField tfAlas;
    JTextField tfTinggi;
    JTextField tfSisiA;
    JTextField tfSisiB;
    JTextField tfSisiC;

    JButton btnHitung;

    JTextArea hasil;

    public FormSegitiga() {

        super("Form Segitiga");

        lAlas = new JLabel("Alas");
        lTinggi = new JLabel("Tinggi");

        lSisiA = new JLabel("Sisi A");
        lSisiB = new JLabel("Sisi B");
        lSisiC = new JLabel("Sisi C");

        tfAlas = new JTextField();
        tfTinggi = new JTextField();

        tfSisiA = new JTextField();
        tfSisiB = new JTextField();
        tfSisiC = new JTextField();

        btnHitung =
                new JButton("Hitung");

        hasil = new JTextArea();

        Container c =
                getContentPane();

        c.setLayout(
                new GridLayout(7,2));

        c.add(lAlas);
        c.add(tfAlas);

        c.add(lTinggi);
        c.add(tfTinggi);

        c.add(lSisiA);
        c.add(tfSisiA);

        c.add(lSisiB);
        c.add(tfSisiB);

        c.add(lSisiC);
        c.add(tfSisiC);

        c.add(btnHitung);
        c.add(hasil);

        btnHitung.addActionListener(this);

        setSize(500,400);

        setVisible(true);
    }

    @Override
    public void actionPerformed(
            ActionEvent e) {

        double alas =
                Double.parseDouble(
                        tfAlas.getText());

        double tinggi =
                Double.parseDouble(
                        tfTinggi.getText());

        double sisiA =
                Double.parseDouble(
                        tfSisiA.getText());

        double sisiB =
                Double.parseDouble(
                        tfSisiB.getText());

        double sisiC =
                Double.parseDouble(
                        tfSisiC.getText());

        Segitiga s =
                new Segitiga(
                        alas,
                        tinggi,
                        sisiA,
                        sisiB,
                        sisiC);

        hasil.setText(
                "Luas : "
                        + s.hitungLuas()
                        + "\nKeliling : "
                        + s.hitungKeliling());
    }
}
