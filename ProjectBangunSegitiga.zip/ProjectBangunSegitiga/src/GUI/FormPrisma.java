/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

/**
 *
 * @author Asus
 */
import BangunDatar.Segitiga;
import BangunRuang.PrismaSegitiga;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FormPrisma
        extends JFrame
        implements ActionListener {

    JLabel lAlas;
    JLabel lTinggiSegitiga;
    JLabel lTinggiPrisma;

    JTextField tfAlas;
    JTextField tfTinggiSegitiga;
    JTextField tfTinggiPrisma;

    JButton btnHitung;

    JTextArea hasil;

    public FormPrisma() {

        super("Form Prisma Segitiga");

        lAlas =
                new JLabel("Alas");

        lTinggiSegitiga =
                new JLabel("Tinggi Segitiga");

        lTinggiPrisma =
                new JLabel("Tinggi Prisma");

        tfAlas = new JTextField();

        tfTinggiSegitiga =
                new JTextField();

        tfTinggiPrisma =
                new JTextField();

        btnHitung =
                new JButton("Hitung");

        hasil =
                new JTextArea();

        Container c =
                getContentPane();

        c.setLayout(
                new GridLayout(5,2));

        c.add(lAlas);
        c.add(tfAlas);

        c.add(lTinggiSegitiga);
        c.add(tfTinggiSegitiga);

        c.add(lTinggiPrisma);
        c.add(tfTinggiPrisma);

        c.add(btnHitung);
        c.add(hasil);

        btnHitung.addActionListener(this);

        setSize(500,300);

        setVisible(true);
    }

    @Override
    public void actionPerformed(
            ActionEvent e) {

        double alas =
                Double.parseDouble(
                        tfAlas.getText());

        double tinggiSegitiga =
                Double.parseDouble(
                        tfTinggiSegitiga.getText());

        double tinggiPrisma =
                Double.parseDouble(
                        tfTinggiPrisma.getText());

        Segitiga s =
                new Segitiga(
                        alas,
                        tinggiSegitiga);

        PrismaSegitiga p =
                new PrismaSegitiga(
                        tinggiPrisma,
                        s);

        hasil.setText(
                "Volume : "
                        + p.hitungVolume());
    }
}
