/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

/**
 *
 * @author Asus
 */
import BangunDatar.Segitiga;
import BangunRuang.LimasSegitiga;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FormLimas
        extends JFrame
        implements ActionListener {

    JLabel lAlas;
    JLabel lTinggiSegitiga;
    JLabel lTinggiLimas;

    JTextField tfAlas;
    JTextField tfTinggiSegitiga;
    JTextField tfTinggiLimas;

    JButton btnHitung;

    JTextArea hasil;

    public FormLimas() {

        super("Form Limas Segitiga");

        lAlas =
                new JLabel("Alas");

        lTinggiSegitiga =
                new JLabel(
                        "Tinggi Segitiga");

        lTinggiLimas =
                new JLabel(
                        "Tinggi Limas");

        tfAlas =
                new JTextField();

        tfTinggiSegitiga =
                new JTextField();

        tfTinggiLimas =
                new JTextField();

        btnHitung =
                new JButton("Hitung");

        hasil =
                new JTextArea();

        Container c =
                getContentPane();

        c.setLayout(
                new GridLayout(5,2));

        c.add(lAlas);
        c.add(tfAlas);

        c.add(lTinggiSegitiga);
        c.add(tfTinggiSegitiga);

        c.add(lTinggiLimas);
        c.add(tfTinggiLimas);

        c.add(btnHitung);
        c.add(hasil);

        btnHitung.addActionListener(this);

        setSize(500,300);

        setVisible(true);
    }

    @Override
    public void actionPerformed(
            ActionEvent e) {

        double alas =
                Double.parseDouble(
                        tfAlas.getText());

        double tinggiSegitiga =
                Double.parseDouble(
                        tfTinggiSegitiga.getText());

        double tinggiLimas =
                Double.parseDouble(
                        tfTinggiLimas.getText());

        Segitiga s =
                new Segitiga(
                        alas,
                        tinggiSegitiga);

        LimasSegitiga l =
                new LimasSegitiga(
                        tinggiLimas,
                        s);

        hasil.setText(
                "Volume : "
                        + l.hitungVolume());
    }
}
