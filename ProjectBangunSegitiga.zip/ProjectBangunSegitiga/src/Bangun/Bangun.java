/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bangun;

/**
 *
 * @author Asus
 */
public class Bangun {
    protected String namaBangun;

    public void tampilInfo() {

        System.out.println(
                "Nama Bangun : "
                        + namaBangun);
    }
}
