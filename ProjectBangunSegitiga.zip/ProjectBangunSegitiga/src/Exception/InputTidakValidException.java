/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exception;

/**
 *
 * @author Asus
 */
public class InputTidakValidException extends Exception {
    
    public InputTidakValidException(String pesan) {
        super(pesan);
    }
}
