package Bangun2Dimensi;

import GUI.MainFrame;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class Segitiga implements Runnable, Bangun2Dimensi {

    // Encapsulation
    protected double alas;
    protected double tinggi;
    protected double sisiA;
    protected double sisiB;
    protected double sisiC;

    protected double luas;
    protected double keliling;

    protected Thread t;
    protected String namaThread;

    // RANGE DATA YANG DIKERJAKAN THREAD
    protected int dataAwal;
    protected int dataAkhir;

    protected JTextArea logArea;
    protected MainFrame gui;
    protected JProgressBar progressBar;

    // Constructor utama
    public Segitiga(
            double alas,
            double tinggi,
            double sisiA,
            double sisiB,
            double sisiC,
            String nama,
            int dataAwal,
            int dataAkhir,
            JTextArea area,
            MainFrame vGui,
            JProgressBar pb) {

        this.alas = alas;
        this.tinggi = tinggi;
        this.sisiA = sisiA;
        this.sisiB = sisiB;
        this.sisiC = sisiC;

        this.namaThread = nama;

        this.dataAwal = dataAwal;
        this.dataAkhir = dataAkhir;

        this.logArea = area;
        this.gui = vGui;
        this.progressBar = pb;

        this.t = new Thread(this, nama);
    }

    // Overloading
    public Segitiga() {

    }

    public Segitiga(double alas, double tinggi) {
        this.alas = alas;
        this.tinggi = tinggi;
    }

    // Getter
    public Thread getThread() {
        return t;
    }

    public String getNamaThread() {
        return namaThread;
    }

    public double getLuas() {
        return luas;
    }

    public double getKeliling() {
        return keliling;
    }

    @Override
    public double hitungLuas() {
        luas = 0.5 * alas * tinggi;
        return luas;
    }

    @Override
    public double hitungKeliling() {
        keliling = sisiA + sisiB + sisiC;
        return keliling;
    }

    @Override
    public void run() {

        try {

            double alasAwal = alas;
            double tinggiAwal = tinggi;

            double sA = sisiA;
            double sB = sisiB;
            double sC = sisiC;

            int totalDataThread =
                    dataAkhir - dataAwal + 1;

            for (int i = dataAwal; i <= dataAkhir; i++) {

                if(i % 100 == 0 || i == dataAkhir){

                    int progress =
                        (int)(((double)(i - dataAwal + 1)
                        / totalDataThread) * 100);

                    SwingUtilities.invokeLater(
                        () -> progressBar.setValue(progress)
                    );

                    Thread.sleep(150);
                }

                alas = alasAwal * i;
                tinggi = tinggiAwal * i;

                sisiA = sA * i;
                sisiB = sB * i;
                sisiC = sC * i;

                hitungLuas();
                hitungKeliling();

                logArea.append(
                        namaThread
                        + " memproses data ke-"
                        + i
                        + "\n"
                );

                gui.tambahBarisTabel(
                        new Object[]{
                            namaThread,
                            "Segitiga",
                            i,
                            luas,
                            keliling,
                            "-",
                            "-"
                        }
                );
            }

            logArea.append(
                    namaThread
                    + " selesai.\n"
            );

        } catch (Exception e) {

            logArea.append(
                    namaThread
                    + " gagal : "
                    + e.getMessage()
                    + "\n"
            );
        }
    }
}