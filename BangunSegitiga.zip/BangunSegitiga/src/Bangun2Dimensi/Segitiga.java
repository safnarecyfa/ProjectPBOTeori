/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bangun2Dimensi;

import GUI.MainFrame;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;

/**
 *
 * @author Asus
 */
// 1. Tambahkan implements Bangun2Dimensi di sini (Multiple Interface)
public class Segitiga implements Runnable, Bangun2Dimensi {

    public double alas, tinggi, sisiA, sisiB, sisiC;
    public double luas, keliling;
    public Thread t;
    public String namaThread;
    public int jumlahData;
    public JTextArea logArea;
    public MainFrame gui;

    public JProgressBar progressBar; // Import javax.swing.JProgressBar

    public Segitiga(double alas, double tinggi, double sisiA, double sisiB, double sisiC, String nama, int n, JTextArea area, MainFrame vGui, JProgressBar pb) {
        this.alas = alas;
        this.tinggi = tinggi;
        this.sisiA = sisiA;
        this.sisiB = sisiB;
        this.sisiC = sisiC;
        this.namaThread = nama;
        this.jumlahData = n;
        this.logArea = area;
        this.progressBar = pb;
        this.gui = vGui;

        this.t = new Thread(this, nama);
    }

    // 2. Tambahkan @Override di atas hitungLuas
    @Override
    public void hitungLuas() {
        this.luas = 0.5 * alas * tinggi;
    }

    // 3. Tambahkan @Override di atas hitungKeliling
    @Override
    public void hitungKeliling() {
        this.keliling = sisiA + sisiB + sisiC;
    }

    @Override
    public void run() {
        try {
            // ... isi method run tetap sama seperti sebelumnya ...
            double alasAwal = this.alas;
            double tinggiAwal = this.tinggi;
            double sA = this.sisiA;
            double sB = this.sisiB;
            double sC = this.sisiC;

            for (int i = 1; i <= jumlahData; i++) {
                int progress = (int) (((double) i / jumlahData) * 100);
                javax.swing.SwingUtilities.invokeLater(() -> progressBar.setValue(progress));

                try {
                    Thread.sleep(100); // Jeda 30 milidetik per data
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }

                this.alas = alasAwal * i;
                this.tinggi = tinggiAwal * i;
                this.sisiA = sA * i;
                this.sisiB = sB * i;
                this.sisiC = sC * i;

                hitungLuas();
                hitungKeliling();

                logArea.append(namaThread + " memproses data ke-" + i + "\n");
                gui.tambahBarisTabel(new Object[]{namaThread, "Segitiga", i, luas, keliling, "-", "-"});

                Thread.sleep(600);
            }
        } catch (InterruptedException e) {
            logArea.append(namaThread + " terganggu.\n");
        }
    }
}
