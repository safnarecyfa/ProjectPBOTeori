/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Main;

import GUI.MainFrame;

/**
 *
 * @author Asus
 */
public class BangunSegitiga {
    public static void main(String[] args) {
        // Menjalankan MainFrame
        new MainFrame();
    }
}
