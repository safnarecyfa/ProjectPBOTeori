package Bangun3Dimensi;

import GUI.MainFrame;
import Bangun2Dimensi.Segitiga;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class LimasSegitiga extends Segitiga implements Bangun3Dimensi {

    protected double tinggiLimas;
    protected double tinggiSisiTegak;

    protected double volume;
    protected double luasPermukaan;

    public LimasSegitiga(
            double alas,
            double tinggi,
            double sisiA,
            double sisiB,
            double sisiC,
            double tinggiLimas,
            double tinggiSisiTegak,
            String namaThread,
            int dataAwal,
            int dataAkhir,
            JTextArea area,
            MainFrame vGui,
            JProgressBar pb) {

        super(
                alas,
                tinggi,
                sisiA,
                sisiB,
                sisiC,
                namaThread,
                dataAwal,
                dataAkhir,
                area,
                vGui,
                pb);

        this.tinggiLimas = tinggiLimas;
        this.tinggiSisiTegak = tinggiSisiTegak;
    }

    @Override
    public double hitungVolume() {

        volume =
                (luas * tinggiLimas)
                / 3.0;

        return volume;
    }

    @Override
    public double hitungLuasPermukaan() {

        double luasSisiTegak =
                3 * (0.5 * alas * tinggiSisiTegak);

        luasPermukaan =
                luas + luasSisiTegak;

        return luasPermukaan;
    }

    @Override
    public void run() {

        try {

            double alasAwal = alas;
            double tinggiAwal = tinggi;

            double sA = sisiA;
            double sB = sisiB;
            double sC = sisiC;

            double tLimasAwal = tinggiLimas;
            double tTegakAwal = tinggiSisiTegak;

            int totalDataThread =
                    dataAkhir - dataAwal + 1;

            for (int i = dataAwal; i <= dataAkhir; i++) {

                if(i % 100 == 0 || i == dataAkhir){

                    int progress =
                        (int)(((double)(i - dataAwal + 1)
                        / totalDataThread) * 100);

                    SwingUtilities.invokeLater(
                        () -> progressBar.setValue(progress)
                    );

                    Thread.sleep(150);
                }

                alas = alasAwal * i;
                tinggi = tinggiAwal * i;

                sisiA = sA * i;
                sisiB = sB * i;
                sisiC = sC * i;

                tinggiLimas = tLimasAwal * i;
                tinggiSisiTegak = tTegakAwal * i;

                hitungLuas();
                hitungKeliling();
                hitungVolume();
                hitungLuasPermukaan();

                logArea.append(
                        namaThread
                        + " memproses data ke-"
                        + i
                        + "\n"
                );

                gui.tambahBarisTabel(
                        new Object[]{
                            namaThread,
                            "Limas Segitiga",
                            i,
                            luas,
                            keliling,
                            volume,
                            luasPermukaan
                        }
                );
            }

            logArea.append(
                    namaThread
                    + " selesai.\n"
            );

        } catch (Exception e) {

            logArea.append(
                    namaThread
                    + " gagal : "
                    + e.getMessage()
                    + "\n"
            );
        }
    }
}