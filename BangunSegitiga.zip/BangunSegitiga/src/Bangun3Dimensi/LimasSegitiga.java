/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bangun3Dimensi;

import GUI.MainFrame;
import Bangun2Dimensi.Segitiga;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;

/**
 *
 * @author Asus
 */

public class LimasSegitiga extends Segitiga implements Bangun3Dimensi {
    public double tinggiLimas;
    public double tinggiSisiTegak;
    public double volume;
    public double luasPermukaan;

    public LimasSegitiga(double alas, double tinggi, double sisiA, double sisiB, double sisiC, double tinggiLimas, double tinggiSisiTegak, String namaThread, int n, JTextArea area, MainFrame vGui, JProgressBar pb) {
        super(alas, tinggi, sisiA, sisiB, sisiC, namaThread, n, area, vGui, pb);
        this.tinggiLimas = tinggiLimas;
        this.tinggiSisiTegak = tinggiSisiTegak;
        this.t = new Thread(this, namaThread);
    }

    // Tambahkan @Override di atas hitungVolume
    @Override
    public void hitungVolume() {
        super.hitungLuas();
        this.volume = (super.luas * tinggiLimas) / 3.0;
    }

    // Tambahkan @Override di atas hitungLuasPermukaan
    @Override
    public void hitungLuasPermukaan() {
        super.hitungLuas();
        super.hitungKeliling();
        double luasSisiTegak = 3 * (0.5 * super.alas * tinggiSisiTegak);
        this.luasPermukaan = super.luas + luasSisiTegak;
    }

    @Override
    public void run() {
        // ... isi method run tetap sama seperti sebelumnya ...
        try {
            double alasAwal = super.alas;
            double tinggiAwal = super.tinggi;
            double sA = super.sisiA;
            double sB = super.sisiB;
            double sC = super.sisiC;
            double tLimasAwal = this.tinggiLimas;
            double tTegakAwal = this.tinggiSisiTegak;

            for (int i = 1; i <= jumlahData; i++) {
                int progress = (int) (((double) i / jumlahData) * 100);
                javax.swing.SwingUtilities.invokeLater(() -> progressBar.setValue(progress));
                
                try {
                    Thread.sleep(100); // Jeda 30 milidetik per data
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                
                super.alas = alasAwal * i;
                super.tinggi = tinggiAwal * i;
                super.sisiA = sA * i;
                super.sisiB = sB * i;
                super.sisiC = sC * i;
                this.tinggiLimas = tLimasAwal * i;
                this.tinggiSisiTegak = tTegakAwal * i;

                hitungVolume();
                hitungLuasPermukaan();
                
                logArea.append(namaThread + " memproses data ke-" + i + "\n");
                super.gui.tambahBarisTabel(new Object[]{namaThread, "Limas Segitiga", i, super.luas, super.keliling, volume, luasPermukaan});
                
                Thread.sleep(600);
            }
        } catch (InterruptedException e) {
            logArea.append(namaThread + " terinterupsi.\n");
        }
    }
}