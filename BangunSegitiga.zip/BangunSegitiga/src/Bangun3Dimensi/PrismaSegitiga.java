/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bangun3Dimensi;

import GUI.MainFrame;
import Bangun2Dimensi.Segitiga;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;

/**
 *
 * @author Asus
 */

public class PrismaSegitiga extends Segitiga implements Bangun3Dimensi {
    public double tinggiPrisma;
    public double volume;
    public double luasPermukaan;

    public PrismaSegitiga(double alas, double tinggi, double sisiA, double sisiB, double sisiC, double tinggiPrisma, String namaThread, int n, JTextArea area, MainFrame vGui, JProgressBar pb) {
        super(alas, tinggi, sisiA, sisiB, sisiC, namaThread, n, area, vGui, pb);
        this.tinggiPrisma = tinggiPrisma;
        this.t = new Thread(this, namaThread);
    }

    // Tambahkan @Override sebagai tanda mematuhi kontrak interface Bangun3Dimensi
    @Override
    public void hitungVolume() {
        super.hitungLuas(); 
        this.volume = super.luas * tinggiPrisma; 
    }

    // Tambahkan @Override di sini juga
    @Override
    public void hitungLuasPermukaan() {
        super.hitungLuas();
        super.hitungKeliling();
        this.luasPermukaan = (2 * super.luas) + (super.keliling * tinggiPrisma);
    }

    @Override
    public void run() {
        // ... isi method run tetap sama seperti sebelumnya ...
        try {
            double alasAwal = super.alas;
            double tinggiAwal = super.tinggi;
            double sA = super.sisiA;
            double sB = super.sisiB;
            double sC = super.sisiC;
            double tPrismaAwal = this.tinggiPrisma;

            for (int i = 1; i <= jumlahData; i++) {
                int progress = (int) (((double) i / jumlahData) * 100);
                javax.swing.SwingUtilities.invokeLater(() -> progressBar.setValue(progress));
                
                try {
                    Thread.sleep(100); // Jeda 30 milidetik per data
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                
                super.alas = alasAwal * i;
                super.tinggi = tinggiAwal * i;
                super.sisiA = sA * i;
                super.sisiB = sB * i;
                super.sisiC = sC * i;
                this.tinggiPrisma = tPrismaAwal * i;

                hitungVolume();
                hitungLuasPermukaan();
                
                logArea.append(namaThread + " memproses data ke-" + i + "\n");
                super.gui.tambahBarisTabel(new Object[]{namaThread, "Prisma Segitiga", i, super.luas, super.keliling, volume, luasPermukaan});
                
                Thread.sleep(600);
            }
        } catch (InterruptedException e) {
            logArea.append(namaThread + " terinterupsi.\n");
        }
    }
}