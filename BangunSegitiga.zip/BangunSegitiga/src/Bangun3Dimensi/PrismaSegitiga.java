package Bangun3Dimensi;

import GUI.MainFrame;
import Bangun2Dimensi.Segitiga;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class PrismaSegitiga extends Segitiga implements Bangun3Dimensi {

    protected double tinggiPrisma;
    protected double volume;
    protected double luasPermukaan;

    public PrismaSegitiga(
            double alas,
            double tinggi,
            double sisiA,
            double sisiB,
            double sisiC,
            double tinggiPrisma,
            String namaThread,
            int dataAwal,
            int dataAkhir,
            JTextArea area,
            MainFrame vGui,
            JProgressBar pb) {

        super(
                alas,
                tinggi,
                sisiA,
                sisiB,
                sisiC,
                namaThread,
                dataAwal,
                dataAkhir,
                area,
                vGui,
                pb);

        this.tinggiPrisma = tinggiPrisma;
    }

    @Override
    public double hitungVolume() {
        volume = luas * tinggiPrisma;
        return volume;
    }

    @Override
    public double hitungLuasPermukaan() {
        luasPermukaan =
                (2 * luas)
                + (keliling * tinggiPrisma);

        return luasPermukaan;
    }

    @Override
    public void run() {

        try {

            double alasAwal = alas;
            double tinggiAwal = tinggi;

            double sA = sisiA;
            double sB = sisiB;
            double sC = sisiC;

            double tPrismaAwal = tinggiPrisma;

            int totalDataThread =
                    dataAkhir - dataAwal + 1;

            for (int i = dataAwal; i <= dataAkhir; i++) {

                if(i % 100 == 0 || i == dataAkhir){

                    int progress =
                        (int)(((double)(i - dataAwal + 1)
                        / totalDataThread) * 100);

                    SwingUtilities.invokeLater(
                        () -> progressBar.setValue(progress)
                    );

                    Thread.sleep(150);
                }

                alas = alasAwal * i;
                tinggi = tinggiAwal * i;

                sisiA = sA * i;
                sisiB = sB * i;
                sisiC = sC * i;

                tinggiPrisma = tPrismaAwal * i;

                hitungLuas();
                hitungKeliling();
                hitungVolume();
                hitungLuasPermukaan();

                logArea.append(
                        namaThread
                        + " memproses data ke-"
                        + i
                        + "\n"
                );

                gui.tambahBarisTabel(
                        new Object[]{
                            namaThread,
                            "Prisma Segitiga",
                            i,
                            luas,
                            keliling,
                            volume,
                            luasPermukaan
                        }
                );
            }

            logArea.append(
                    namaThread
                    + " selesai.\n"
            );

        } catch (Exception e) {

            logArea.append(
                    namaThread
                    + " gagal : "
                    + e.getMessage()
                    + "\n"
            );
        }
    }
}