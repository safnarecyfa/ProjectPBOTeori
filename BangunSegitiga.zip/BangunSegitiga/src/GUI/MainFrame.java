/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

/**
 *
 * @author Asus
 */
import Bangun2Dimensi.Segitiga;
import Bangun3Dimensi.PrismaSegitiga;
import Bangun3Dimensi.LimasSegitiga;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;

public class MainFrame extends JFrame implements ActionListener {

    // Definisi Warna Modern
    private final Color PRIMARY_COLOR = new Color(26, 35, 126); // Navy Deep
    private final Color ACCENT_COLOR = new Color(33, 150, 243);  // Bright Blue
    private final Color BG_COLOR = new Color(240, 242, 245);     // Light Gray BG
    private final Color SUCCESS_COLOR = new Color(46, 125, 50);  // Green

    // Komponen Input
    JTextField tfData = new JTextField("3"), tfThread = new JTextField("1");
    JTextField tfAlas = new JTextField("6"), tfTinggi = new JTextField("4");
    JTextField tfSisiA = new JTextField("6"), tfSisiB = new JTextField("5"), tfSisiC = new JTextField("5");
    JTextField tfTgiPrisma = new JTextField("10"), tfTgiLimas = new JTextField("12"), tfTgiTegak = new JTextField("8");

    JButton bRun = new JButton("MULAI PROSES KOMPUTASI");
    JTextArea logArea = new JTextArea();
    DefaultTableModel tableModel;
    JTable tabelHasil;

    public MainFrame() {
        super("Geometric Engine Pro - Multithreading Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Step 1: Look and Feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
        }

        // Layout Utama
        Container kontainer = this.getContentPane();
        kontainer.setLayout(new BorderLayout(0, 0));
        kontainer.setBackground(BG_COLOR);

        // --- 1. HEADER SECTION ---
        JPanel pHeader = new JPanel(new BorderLayout());
        pHeader.setBackground(PRIMARY_COLOR);
        pHeader.setPreferredSize(new Dimension(100, 80));
        JLabel lTitle = new JLabel(" GEOMETRIC MULTITHREADING", JLabel.LEFT);
        lTitle.setForeground(Color.WHITE);
        lTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lTitle.setBorder(BorderFactory.createEmptyBorder(0, 25, 0, 0));
        pHeader.add(lTitle, BorderLayout.CENTER);
        kontainer.add(pHeader, BorderLayout.NORTH);

        // --- 2. INPUT SECTION (LEFT SIDE) ---
        JPanel pLeft = new JPanel();
        pLeft.setLayout(new BoxLayout(pLeft, BoxLayout.Y_AXIS));
        pLeft.setPreferredSize(new Dimension(320, 100));
        pLeft.setBackground(Color.WHITE);
        pLeft.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 0, 1, Color.LIGHT_GRAY),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        pLeft.add(createInputCard("⚙️ KONTROL SISTEM", new String[]{"Jumlah Data", "Jumlah Thread"}, new JTextField[]{tfData, tfThread}));
        pLeft.add(Box.createVerticalStrut(15));
        pLeft.add(createInputCard("📐 DIMENSI ALAS", new String[]{"Alas", "Tinggi", "Sisi A", "Sisi B", "Sisi C"}, new JTextField[]{tfAlas, tfTinggi, tfSisiA, tfSisiB, tfSisiC}));
        pLeft.add(Box.createVerticalStrut(15));
        pLeft.add(createInputCard("📦 DIMENSI RUANG", new String[]{"Tgi Prisma", "Tgi Limas", "Tgi Sisi Tegak"}, new JTextField[]{tfTgiPrisma, tfTgiLimas, tfTgiTegak}));
        pLeft.add(Box.createVerticalGlue());

        // Tombol Run Modern
        bRun.setAlignmentX(Component.CENTER_ALIGNMENT);
        bRun.setMaximumSize(new Dimension(300, 50));
        bRun.setBackground(ACCENT_COLOR);
        bRun.setForeground(Color.WHITE);
        bRun.setFont(new Font("Segoe UI", Font.BOLD, 14));
        bRun.setFocusPainted(false);
        bRun.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        bRun.setCursor(new Cursor(Cursor.HAND_CURSOR));
        pLeft.add(bRun);
        kontainer.add(pLeft, BorderLayout.WEST);

        // --- 3. OUTPUT SECTION (CENTER) ---
        JPanel pCenter = new JPanel(new BorderLayout());
        pCenter.setBackground(BG_COLOR);
        pCenter.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Tabbed Pane (Materi PPT 9)
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        // Tab Log
        logArea.setBackground(new Color(33, 33, 33));
        logArea.setForeground(new Color(129, 199, 132));
        logArea.setFont(new Font("Consolas", Font.PLAIN, 13));
        logArea.setMargin(new Insets(10, 10, 10, 10));
        tabs.addTab("  🖥️ MONITORING LOG  ", new JScrollPane(logArea));

        // Tab Tabel
        String[] kolom = {"Thread", "Bangun", "Data", "Luas Alas", "Keliling", "Volume", "L. Permukaan"};
        tableModel = new DefaultTableModel(kolom, 0);
        tabelHasil = new JTable(tableModel);
        tabelHasil.setRowHeight(30);
        tabelHasil.setIntercellSpacing(new Dimension(10, 10));
        tabelHasil.setShowVerticalLines(false);
        tabelHasil.setGridColor(new Color(230, 230, 230));

        // Header Tabel
        JTableHeader th = tabelHasil.getTableHeader();
        th.setPreferredSize(new Dimension(100, 35));
        th.setFont(new Font("Segoe UI", Font.BOLD, 13));
        th.setBackground(Color.WHITE);

        tabs.addTab("  📊 DATA CALCULATIONS  ", new JScrollPane(tabelHasil));

        pCenter.add(tabs, BorderLayout.CENTER);
        kontainer.add(pCenter, BorderLayout.CENTER);

        // Event Handling
        bRun.addActionListener(this);

        this.setSize(1100, 700);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    // Helper untuk membuat grup input yang cantik (Card Style)
    private JPanel createInputCard(String title, String[] labels, JTextField[] fields) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);

        JLabel lTitle = new JLabel(title);
        lTitle.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lTitle.setForeground(PRIMARY_COLOR);
        lTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(lTitle);
        card.add(Box.createVerticalStrut(10));

        for (int i = 0; i < labels.length; i++) {
            JPanel pRow = new JPanel(new BorderLayout());
            pRow.setBackground(Color.WHITE);
            pRow.setMaximumSize(new Dimension(300, 30));

            JLabel lb = new JLabel(labels[i]);
            lb.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            pRow.add(lb, BorderLayout.WEST);

            fields[i].setHorizontalAlignment(JTextField.RIGHT);
            fields[i].setPreferredSize(new Dimension(80, 25));
            pRow.add(fields[i], BorderLayout.EAST);

            card.add(pRow);
            card.add(Box.createVerticalStrut(5));
        }
        return card;
    }

    public synchronized void tambahBarisTabel(Object[] rowData) {
        tableModel.addRow(rowData);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == bRun) {
            logArea.setText("[SYSTEM] Menyiapkan environment...\n");
            tableModel.setRowCount(0);
            bRun.setEnabled(false);

            int nData = Integer.parseInt(tfData.getText());
            int nThread = Integer.parseInt(tfThread.getText());
            double vAlas = Double.parseDouble(tfAlas.getText());
            double vTinggi = Double.parseDouble(tfTinggi.getText());
            double vSisiA = Double.parseDouble(tfSisiA.getText());
            double vSisiB = Double.parseDouble(tfSisiB.getText());
            double vSisiC = Double.parseDouble(tfSisiC.getText());
            double vTgiPrisma = Double.parseDouble(tfTgiPrisma.getText());
            double vTgiLimas = Double.parseDouble(tfTgiLimas.getText());
            double vTgiTegak = Double.parseDouble(tfTgiTegak.getText());

            new Thread(() -> {
                logArea.append("[SYSTEM] Eksekusi " + (nThread * 3) + " thread dimulai...\n");
                long start = System.currentTimeMillis();

                int total = nThread * 3;
                Segitiga[] bng = new Segitiga[total];
                int idx = 0;
                for (int i = 1; i <= nThread; i++) {
                    // 1. BAGIAN DIUBAH: Menggunakan SegitigaNyata menggantikan abstract class Segitiga
                    bng[idx++] = new Segitiga(vAlas, vTinggi, vSisiA, vSisiB, vSisiC, "Segitiga-" + i, nData, logArea, MainFrame.this);
                    bng[idx++] = new PrismaSegitiga(vAlas, vTinggi, vSisiA, vSisiB, vSisiC, vTgiPrisma, "Prisma-" + i, nData, logArea, MainFrame.this);
                    bng[idx++] = new LimasSegitiga(vAlas, vTinggi, vSisiA, vSisiB, vSisiC, vTgiLimas, vTgiTegak, "Limas-" + i, nData, logArea, MainFrame.this);
                }

                for (Segitiga s : bng) {
                    s.t.start();
                }
                for (Segitiga s : bng) {
                    try {
                        s.t.join();
                    } catch (Exception ex) {
                    }
                }

                long totalTime = System.currentTimeMillis() - start;

                // 2. BAGIAN DIUBAH: Konversi totalTime (milidetik) ke Satuan Detik (s)
                double waktuDetik = totalTime / 1000.0;

                logArea.append("\n====================================\n");
                logArea.append("  DONE: Komputasi Selesai!\n");

                // 3. BAGIAN DIUBAH: Mencetak waktu ke format desimal detik (2 angka di belakang koma)
                logArea.append("  Total Waktu: " + String.format("%.2f", waktuDetik) + " s\n");
                logArea.append("====================================\n");
                bRun.setEnabled(true);
            }).start();
        }
    }

}
