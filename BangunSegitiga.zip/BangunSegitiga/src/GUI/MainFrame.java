/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

/**
 *
 * @author Asus
 */
import Bangun2Dimensi.Segitiga;
import Bangun3Dimensi.PrismaSegitiga;
import Bangun3Dimensi.LimasSegitiga;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;

public class MainFrame extends JFrame implements ActionListener {

    // Definisi Warna Modern
    private final Color PRIMARY_COLOR = new Color(26, 35, 126); // Navy Deep
    private final Color ACCENT_COLOR = new Color(33, 150, 243);  // Bright Blue
    private final Color BG_COLOR = new Color(240, 242, 245);     // Light Gray BG
    private final Color SUCCESS_COLOR = new Color(46, 125, 50);  // Green

    // Komponen Input
    JTextField tfData = new JTextField("3"), tfThread = new JTextField("1");
    JTextField tfAlas = new JTextField("6"), tfTinggi = new JTextField("4");
    JTextField tfSisiA = new JTextField("6"), tfSisiB = new JTextField("5"), tfSisiC = new JTextField("5");
    JTextField tfTgiPrisma = new JTextField("10"), tfTgiLimas = new JTextField("12"), tfTgiTegak = new JTextField("8");

    JButton bRun = new JButton("MULAI PROSES KOMPUTASI");
    JButton bReset = new JButton("RESET DASHBOARD");

    JTextArea logArea = new JTextArea();
    DefaultTableModel tableModel;
    JTable tabelHasil;

    // TAMBAHKAN BARIS INI: Panel dinamis untuk menampung bar loading
    JPanel pProgressContainer = new JPanel();

    public MainFrame() {
        super("Geometric Engine Pro - Multithreading Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Step 1: Look and Feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
        }

        // Layout Utama
        Container kontainer = this.getContentPane();
        kontainer.setLayout(new BorderLayout(0, 0));
        kontainer.setBackground(BG_COLOR);

        // --- 1. HEADER SECTION ---
        JPanel pHeader = new JPanel(new BorderLayout());
        pHeader.setBackground(PRIMARY_COLOR);
        pHeader.setPreferredSize(new Dimension(100, 80));
        JLabel lTitle = new JLabel(" GEOMETRIC MULTITHREADING", JLabel.LEFT);
        lTitle.setForeground(Color.WHITE);
        lTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lTitle.setBorder(BorderFactory.createEmptyBorder(0, 25, 0, 0));
        pHeader.add(lTitle, BorderLayout.CENTER);
        kontainer.add(pHeader, BorderLayout.NORTH);

        // --- 2. INPUT SECTION (LEFT SIDE) ---
        JPanel pLeft = new JPanel();
        pLeft.setLayout(new BoxLayout(pLeft, BoxLayout.Y_AXIS));
        pLeft.setPreferredSize(new Dimension(320, 100));
        pLeft.setBackground(Color.WHITE);
        pLeft.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 0, 1, Color.LIGHT_GRAY),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        pLeft.add(createInputCard("KONTROL SISTEM", new String[]{"Jumlah Data", "Jumlah Thread"}, new JTextField[]{tfData, tfThread}));
        pLeft.add(Box.createVerticalStrut(15));
        pLeft.add(createInputCard("DIMENSI ALAS", new String[]{"Alas", "Tinggi", "Sisi A", "Sisi B", "Sisi C"}, new JTextField[]{tfAlas, tfTinggi, tfSisiA, tfSisiB, tfSisiC}));
        pLeft.add(Box.createVerticalStrut(15));
        pLeft.add(createInputCard("DIMENSI RUANG", new String[]{"Tgi Prisma", "Tgi Limas", "Tgi Sisi Tegak"}, new JTextField[]{tfTgiPrisma, tfTgiLimas, tfTgiTegak}));
        pLeft.add(Box.createVerticalGlue());

        // Tombol Run Modern
        bRun.setText("MULAI PROSES KOMPUTASI"); // Pastikan teksnya diset ulang
        bRun.setAlignmentX(Component.CENTER_ALIGNMENT);
        bRun.setMaximumSize(new Dimension(300, 45));
        bRun.setBackground(ACCENT_COLOR);
        bRun.setForeground(Color.WHITE); // <-- INI WAJIB: Memastikan teks berwarna putih
        bRun.setFont(new Font("Segoe UI", Font.BOLD, 13));
        bRun.setFocusPainted(false);
        bRun.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        bRun.setCursor(new Cursor(Cursor.HAND_CURSOR));
        pLeft.add(bRun);
        kontainer.add(pLeft, BorderLayout.WEST);

        pLeft.add(Box.createVerticalStrut(10)); // Jarak antar tombol
        bReset.setAlignmentX(Component.CENTER_ALIGNMENT);
        bReset.setMaximumSize(new Dimension(300, 40));
        bReset.setBackground(new Color(211, 47, 47)); // Warna Merah (Red Accent)
        bReset.setForeground(Color.WHITE);
        bReset.setFont(new Font("Segoe UI", Font.BOLD, 13));
        bReset.setFocusPainted(false);
        bReset.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        bReset.setCursor(new Cursor(Cursor.HAND_CURSOR));
        pLeft.add(bReset);

        kontainer.add(pLeft, BorderLayout.WEST);

        // --- 3. OUTPUT SECTION (CENTER) ---
        JPanel pCenter = new JPanel(new BorderLayout());
        pCenter.setBackground(BG_COLOR);
        pCenter.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Tabbed Pane (Materi PPT 9)
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        // Tab Log
        logArea.setBackground(new Color(33, 33, 33));
        logArea.setForeground(new Color(129, 199, 132));
        logArea.setFont(new Font("Consolas", Font.PLAIN, 13));
        logArea.setMargin(new Insets(10, 10, 10, 10));
        tabs.addTab("  MONITORING LOG  ", new JScrollPane(logArea));

        // Tab Tabel
        String[] kolom = {"Thread", "Bangun", "Data", "Luas Alas", "Keliling", "Volume", "L. Permukaan"};
        tableModel = new DefaultTableModel(kolom, 0);
        tabelHasil = new JTable(tableModel);
        tabelHasil.setRowHeight(30);
        tabelHasil.setIntercellSpacing(new Dimension(10, 10));
        tabelHasil.setShowVerticalLines(false);
        tabelHasil.setGridColor(new Color(230, 230, 230));

        // Header Tabel
        JTableHeader th = tabelHasil.getTableHeader();
        th.setPreferredSize(new Dimension(100, 35));
        th.setFont(new Font("Segoe UI", Font.BOLD, 13));
        th.setBackground(Color.WHITE);

        tabs.addTab("  DATA CALCULATIONS  ", new JScrollPane(tabelHasil));

        pProgressContainer.setLayout(new BoxLayout(pProgressContainer, BoxLayout.Y_AXIS));
        pProgressContainer.setBackground(Color.WHITE);
        pProgressContainer.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        tabs.addTab("  PROGRESS THREAD  ", new JScrollPane(pProgressContainer));

        pCenter.add(tabs, BorderLayout.CENTER);
        kontainer.add(pCenter, BorderLayout.CENTER);

        pCenter.add(tabs, BorderLayout.CENTER);
        kontainer.add(pCenter, BorderLayout.CENTER);

        // Event Handling
        bRun.addActionListener(this);

        bRun.addActionListener(this);
        bReset.addActionListener(this);

        this.setSize(1100, 700);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    // Helper untuk membuat grup input yang cantik (Card Style)
    private JPanel createInputCard(String title, String[] labels, JTextField[] fields) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);

        JLabel lTitle = new JLabel(title);
        lTitle.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lTitle.setForeground(PRIMARY_COLOR);
        lTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(lTitle);
        card.add(Box.createVerticalStrut(10));

        for (int i = 0; i < labels.length; i++) {
            JPanel pRow = new JPanel(new BorderLayout());
            pRow.setBackground(Color.WHITE);
            pRow.setMaximumSize(new Dimension(300, 30));

            JLabel lb = new JLabel(labels[i]);
            lb.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            pRow.add(lb, BorderLayout.WEST);

            fields[i].setHorizontalAlignment(JTextField.RIGHT);
            fields[i].setPreferredSize(new Dimension(80, 25));
            pRow.add(fields[i], BorderLayout.EAST);

            card.add(pRow);
            card.add(Box.createVerticalStrut(5));
        }
        return card;
    }

    public synchronized void tambahBarisTabel(Object[] rowData) {
        tableModel.addRow(rowData);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == bRun) {
            logArea.setText("[SYSTEM] Menyiapkan environment...\n");
            tableModel.setRowCount(0);
            pProgressContainer.removeAll();
            pProgressContainer.revalidate();
            bRun.setEnabled(false);

            // 1. Ambil data kontrol sistem terlebih dahulu (wajib diisi angka)
            int nData = Integer.parseInt(tfData.getText());
            int nThread = Integer.parseInt(tfThread.getText());

            // 2. Logika Penyelamat: Jika kotak geometri KOSONG, ambil nilai dari 'nData' atau 'nThread'
            // Jika Alas kosong, ganti otomatis pakai angka dari Jumlah Data
            double vAlas = tfAlas.getText().trim().isEmpty() ? nData : Double.parseDouble(tfAlas.getText());

            // Jika Tinggi Alas kosong, ganti otomatis pakai angka dari Jumlah Thread
            double vTinggi = tfTinggi.getText().trim().isEmpty() ? nThread : Double.parseDouble(tfTinggi.getText());

            // Sisi-sisi segitiga lainnya (jika kosong, default kita samakan dengan vAlas)
            double vSisiA = tfSisiA.getText().trim().isEmpty() ? vAlas : Double.parseDouble(tfSisiA.getText());
            double vSisiB = tfSisiB.getText().trim().isEmpty() ? vAlas : Double.parseDouble(tfSisiB.getText());
            double vSisiC = tfSisiC.getText().trim().isEmpty() ? vAlas : Double.parseDouble(tfSisiC.getText());

            // Dimensi bangun ruang (jika kosong, kita ambil dari nData dikalikan sesuatu agar proporsional)
            double vTgiPrisma = tfTgiPrisma.getText().trim().isEmpty() ? (nData * 2) : Double.parseDouble(tfTgiPrisma.getText());
            double vTgiLimas = tfTgiLimas.getText().trim().isEmpty() ? (nData * 3) : Double.parseDouble(tfTgiLimas.getText());
            double vTgiTegak = tfTgiTegak.getText().trim().isEmpty() ? (nData * 2) : Double.parseDouble(tfTgiTegak.getText());

            new Thread(() -> {
                logArea.append("[SYSTEM] Eksekusi " + (nThread * 3) + " thread dimulai...\n");
                long start = System.currentTimeMillis();

                int total = nThread * 3;
                Segitiga[] bng = new Segitiga[total];
                int idx = 0;
                for (int i = 1; i <= nThread; i++) {
                    // UBAH BAGIAN INI: Membuat bar loading sekaligus memasukkannya ke parameter constructor objek bangun
                    String nSegitiga = "Segitiga-" + i;
                    JProgressBar pbSegitiga = buatProgressBar(nSegitiga);
                    bng[idx++] = new Segitiga(vAlas, vTinggi, vSisiA, vSisiB, vSisiC, nSegitiga, nData, logArea, MainFrame.this, pbSegitiga);

                    String nPrisma = "Prisma-" + i;
                    JProgressBar pbPrisma = buatProgressBar(nPrisma);
                    bng[idx++] = new PrismaSegitiga(vAlas, vTinggi, vSisiA, vSisiB, vSisiC, vTgiPrisma, nPrisma, nData, logArea, MainFrame.this, pbPrisma);

                    String nLimas = "Limas-" + i;
                    JProgressBar pbLimas = buatProgressBar(nLimas);
                    bng[idx++] = new LimasSegitiga(vAlas, vTinggi, vSisiA, vSisiB, vSisiC, vTgiLimas, vTgiTegak, nLimas, nData, logArea, MainFrame.this, pbLimas);
                }

                for (Segitiga s : bng) {
                    s.t.start();
                }
                for (Segitiga s : bng) {
                    try {
                        s.t.join();
                    } catch (Exception ex) {
                    }
                }

                long totalTime = System.currentTimeMillis() - start;
                double waktuDetik = totalTime / 1000.0;

                logArea.append("\n====================================\n");
                logArea.append("  DONE: Komputasi Selesai!\n");
                logArea.append("  Total Waktu: " + String.format("%.2f", waktuDetik) + " s\n");
                logArea.append("====================================\n");
                bRun.setEnabled(true);
            }).start();
        } 
        else if (e.getSource() == bReset) {
            // Logika Reset
            tfData.setText("3");
            tfThread.setText("1");
            tfAlas.setText("6");
            tfTinggi.setText("4");
            tfSisiA.setText("6");
            tfSisiB.setText("5");
            tfSisiC.setText("5");
            tfTgiPrisma.setText("10");
            tfTgiLimas.setText("12");
            tfTgiTegak.setText("8");

            logArea.setText("[SYSTEM] Dashboard berhasil di-reset ke pengaturan awal.\n");
            tableModel.setRowCount(0);

            pProgressContainer.removeAll();
            pProgressContainer.revalidate();
            pProgressContainer.repaint();

            bRun.setEnabled(true);
            bRun.setText("MULAI PROSES KOMPUTASI"); // Kembalikan teks tombol jika hilang
        }
    }

    // membuat bar loading dinamis per thread bangun geometri
    public JProgressBar buatProgressBar(String namaThread) {
        JPanel pBar = new JPanel(new BorderLayout(10, 0));
        pBar.setBackground(Color.WHITE);
        pBar.setMaximumSize(new Dimension(1000, 45));
        pBar.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        JLabel lblNama = new JLabel(namaThread);
        lblNama.setPreferredSize(new Dimension(120, 20));
        lblNama.setFont(new Font("Segoe UI", Font.BOLD, 12));

        JProgressBar progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true); // Memunculkan persentase teks (ex: 50%)
        progressBar.setForeground(ACCENT_COLOR);
        progressBar.setFont(new Font("Segoe UI", Font.PLAIN, 11));

        pBar.add(lblNama, BorderLayout.WEST);
        pBar.add(progressBar, BorderLayout.CENTER);

        pProgressContainer.add(pBar);
        pProgressContainer.add(Box.createVerticalStrut(5));

        // Memaksa UI memperbarui tampilan komponen baru yang ditambahkan
        pProgressContainer.revalidate();
        pProgressContainer.repaint();

        return progressBar;
    }

}
